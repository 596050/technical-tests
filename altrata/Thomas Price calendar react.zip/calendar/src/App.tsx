import { Calendar } from "@components";

export const App = () => <Calendar date={new Date()} />;
