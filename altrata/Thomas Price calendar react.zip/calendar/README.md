By using babel’s support for TypeScript, you get the ability to work with
existing build pipelines and are more likely to have a faster JS emit time
because Babel does not type check your code.
